﻿using MissNancy.Services;

namespace MissNancy.Services
{
   
    public class ClassService
    {


    }
}
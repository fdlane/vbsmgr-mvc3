Ext.define('KCCVBS.model.Ages', {
    extend: 'Ext.data.Model',
    fields: ['AgeKey', 'Active','Age', 'Color', 'Notes', 'CreateDate', 'CreatedBy', 'EditDate', 'EditedBy']
});

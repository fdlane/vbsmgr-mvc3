/*

This file is part of Ext JS 4

Copyright (c) 2011 Sencha Inc

Contact:  http://www.sencha.com/contact

GNU General Public License Usage
This file may be used under the terms of the GNU General Public License version 3.0 as published by the Free Software Foundation and appearing in the file LICENSE included in the packaging of this file.  Please review the following information to ensure the GNU General Public License version 3.0 requirements will be met: http://www.gnu.org/copyleft/gpl.html.

If you are unsure which license is appropriate for your use, please contact the sales department at http://www.sencha.com/contact.

*/



Ext.define('KCCVBS.view.user.Edit', {
    extend: 'Ext.window.Window',
    alias: 'widget.useredit',

    requires: ['Ext.form.Panel'],

    title: 'Edit User',
    layout: 'fit',
    autoShow: true,
    height: 120,
    width: 280,

    initComponent: function () {
        this.items = [
        {
            xtype: 'form',
            padding: '5 5 0 5',
            border: false,
            style: 'background-color: #fff;',

            items: [
            {
                xtype: 'textfield',
                name: 'Name',
                fieldLabel: 'Name'
            },
            {
                xtype: 'textfield',
                name: 'Email',
                fieldLabel: 'Email'
            }
                ]
        }
        ];

        this.buttons = [
        {
            text: 'Save',
            action: 'save'
        },
        {
            text: 'Cancel',
            scope: this,
            handler: this.close
        }
        ];

        this.callParent(arguments);
    }
});

